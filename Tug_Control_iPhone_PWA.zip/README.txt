TUG CONTROL — iPhone

FILES
index.html
manifest.webmanifest
sw.js

LOCAL USE
Transfer the folder/files to your iPhone. index.html can be opened as a webpage, but iOS may only preview local HTML depending on the app used.

HOME SCREEN / FULL-SCREEN APP
For a true installable iPhone web app, upload these three files together to any HTTPS web host.
Then on iPhone:
1. Open the HTTPS address in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Open Tug Control from the new Home Screen icon.

After the first successful load/install, the service worker caches the app for offline use.

ORDER HISTORY
The app stores its order history in browser local storage. Closing and reopening the installed app should retain the log.
Use Export CSV to make a separate copy of the order log.
